<?php get_header(); ?>

	<div id="container" class="clearfix">
		
		<div id="content">
		<div id="errorboxoutline">
			<div id="error-code"><?php _e('404', 'dw-wallpress') ?></div>
			<div id="error-message"><?php _e('Nothing Found', 'dw-wallpress') ?></div>
		</div>
		</div>
		<!-- #content -->
	</div>
	<!-- #container -->

<?php get_footer(); ?>