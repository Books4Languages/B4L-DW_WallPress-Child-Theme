<div id="container" class="clearfix">
	<div id="content">
		<div class="item">
			<div class="item-inner">
				<?php if( is_page() || is_archive() ) { ?>
				<div class="item-main">
					<div class="item-header">
						<h2 class="item-title"><?php _e( 'Question & Answer', 'dw-fixel' ); ?></h2>
					</div>
				</div>
				<?php } ?>
				<div class="item-content">
            