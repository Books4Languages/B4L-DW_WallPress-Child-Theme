</div><!-- Main -->
<a href="#header" class="scroll-top"><i class="fa fa-caret-up"></i></a>
<?php wp_footer(); ?>

</body>
</html>